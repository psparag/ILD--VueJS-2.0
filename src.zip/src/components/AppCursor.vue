<template>
     <div class="cursor w-20 fixed z-50 pointer-events-none top-0 left-0">
        <p></p>
        <img src="../assets/default_cursor.svg" alt />
    </div>
</template>

<script>
export default {
    name: "AppCursor"
}
</script>