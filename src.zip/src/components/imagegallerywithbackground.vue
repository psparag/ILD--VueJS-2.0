<template>
  <div
    class="break-image-section-grid--row2 break-image-section-with-background-grid--row overflow-x-hidden mt-40 py-40"
  >
    <div class="break-image-section-grid-row2--grid">
      <div
        :class="`break-image-section-grid-row2-grid--column bg-gray-800 ` +  ( n % 2 == 0 ? 'mt-16':'')"
        v-for="n in 3"
        :key="n"
      ></div>
    </div>
  </div>
</template>

<script>
export default {
  name: "imagegallerywithbackground"
};
</script>