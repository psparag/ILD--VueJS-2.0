<template>
  <!-- about us page section    -->
  <div class="about-us-stats-section pt-32">
    <div class="about-us-stats-section--container relative overflow-x-hidden">
      <div class="about-us-stats-section-container--grid pl-32">
        <!-- item -->
        <div
          v-for="(galleryitem, index) in imagegallerydata"
          :class="'stats-item-container stats-item-1 ' +  ( index % 2 != 0 ? 'mt-16':'')"
          :key="galleryitem.id"
        >
          <div class="stat-item-container-grid relative">
            <div class="stats-number z-10 pointer-events-none smli-font mx-auto">{{galleryitem.id}}</div>

            <div class="stats-image-container relative">
              <div class="stats-image overflow-hidden mx-auto">
                <img :src="getImgUrl(galleryitem.img)" alt class="h-full w-full object-cover" />
              </div>
              <div
                class="stats-info-container text-center w-full pointer-events-none text-gray-900 absolute leading-tight text-sm uppercase letter-spacing-2"
              >
                <p>{{galleryitem.text}}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "imagegallerywithtext",
  props: ["imagegallerydata"],
  methods: {
    getImgUrl: function(img) {
      return require("../assets/img/" + img);
    }
  }
};
</script>