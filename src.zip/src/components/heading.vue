<template>
  <div>
    <div
      v-bind:class="`break-image-section-grid--row1 ` + ( headingdata.extraclass ? headingdata.extraclass : '')"
      v-if="headingdata.headingsize === 'small'"
    >
      <p class="text-lg uppercase smli-font text-center">
        <span class="text-gray-500">{{headingdata.headingid}} /</span>

        <span class="text-gray-900 letter-spacing-4">{{headingdata.headingtext}}</span>
      </p>
      <div
        class="break-image-section-grid-row1--text text-3xl text-center mt-20 mx-auto leading-tight font-hairline"
      >
        <div class="text-gray-900 c-paragraph-text" v-html="headingdata.paragraphtext"></div>
      </div>
    </div>

    <div
      class="break-image-section-grid--row3 pt-56"
      v-else-if="headingdata.headingsize === 'large'"
    >
      <p
        class="break-image-section-grid-row3--large-text leading-tight text-5xl text-center letter-spacing-10 uppercase text-gray-900 smli-font"
      >
        <span class="text-gray-500">{{headingdata.headingid}}/</span>
        {{headingdata.headingtext}}
      </p>
      <div
        class="break-image-section-grid-row3--text text-gray-900 text-2xl text-center mt-20 mx-auto leading-snug"
      >
        <div class="text-gray-900 c-paragraph-text" v-html="headingdata.paragraphtext"></div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "headingwithtext",
  props: {
    headingdata: Object
  }
};
</script>