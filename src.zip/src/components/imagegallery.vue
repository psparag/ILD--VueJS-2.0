<template>
  <div
    v-bind:class="`break-image-section-grid--row2 image-gallery-scroll--animation ` + (imagegalleryclass ? imagegalleryclass : '')"
  >
    <div class="break-image-section-grid-row2--grid">
      <div
        :class="`break-image-section-grid-row2-grid--column image-gallery--item bg-gray-800 ` +  ( (index + 1) % 2 == 0 ? 'mt-16':'')"
        v-for="(bgimage, index) in bgImages"
        :key="index"
      > 
        <div class="gallery-image overflow-hidden mx-auto" v-bind:style=" {'background-image' : 'url(' + getImgUrl(bgimage) + ')'} ">
                  <!-- <img :src="getImgUrl('1.jpg')" alt class="h-full w-full object-cover" /> -->
                  <!-- <p>test</p> -->
        </div>
        <div class="gallery-overlay"></div>
      
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "imagegallery",
  props: ["imagegalleryclass"],
  data() {
    return {
      bgImages: ["1.jpg","2.jpg","3.jpg"]

    }
  },
  methods: {
      getImgUrl: function(img) {
        return require("../assets/img/"+img);
    }
  }
};
</script>