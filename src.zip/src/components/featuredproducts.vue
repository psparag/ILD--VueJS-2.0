<template>
  <div :class="`feature-partner-section-grid-row2-grid--column1 ` + margintopclass(marginclass)">
    <p
      class="text-lg text-center feature-partner-section-grid-row2-grid-column1--heading smli-font uppercase letter-spacing-4"
    >Featured products from partners</p>
    <div class="feature-partner-section-grid-row2-grid-column1--grid pt-16">
      <div
        v-for="(project, index) in featuredprojects"
        :key="project.projectId"
        v-bind:class="`feature-project-1 ` +  ( (index + 1) % 2 == 0 ? 'mt-16':'') "
      >
      <router-link :to=" {name: 'ProductSingle', params: {slug: project.slug}} ">
        <img
          :src="getImgUrl(project.thumbnailUrl)"
          alt
          class="w-full bg-gray-800 object-cover img-size-responsive feature-items-on-hover-animation"
        />
      </router-link>
      <router-link :to=" {name: 'ProductSingle', params: {slug: project.slug}} ">
        <div class="feature-product-grid pt-5">
          <p class="text-sm feature-product-grid--text uppercase">{{ project.heroSection.title }}</p>
          <div></div>
          <img
            :src="getImgUrl('right_small_arrow.svg')"
            alt
            class="w-6 h-4 feature-partner-section--arrow"
          />
        </div>
      </router-link>
      </div>
    </div>
  </div>
</template>

<script>
import projects from '../json/projects.json'

export default {
    name:'featuredproducts',
    props: ['marginclass'],
    data() {
        return {
            projects: projects,
        }
    },
    computed: {
        featuredprojects: function () {
            return this.projects.filter(function (project) {
                return project.type === 'featured'
            })
        }
    },
    methods: {
      getImgUrl: function(img) {
        return require('../assets/img/'+img)
      },
      margintopclass: function(marginclass){
         return  (marginclass ? marginclass : '')
      }
    }
    
}
</script>