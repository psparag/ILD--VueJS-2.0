<template>
  <div class="projects-section mt-48">
    <!-- gallery -->
    <div class="gallery-container relative overflow-x-hidden pt-32">
      <div class="movable-gallery-container relative z-10 pl-16">
        <!-- item 1 -->
        <div
          v-bind:class="`movable-gallery-item relative ` +  ( (index + 1) % 2 == 0 ? 'mt-16':'') "
          v-for="(project, index) in projects"
          :key="project.id"
        >
        <router-link :to=" {name: 'ProductSingle', params: {slug: project.slug}} ">
          <div
            class="movable-gallery-number text-2xl z-10 pointer-events-none smli-font"
          >{{ project.heroSection.id }}</div>
          <div class="movable-gallery-image-container">
            <div class="movable-gallery-image mx-16 overflow-hidden">
              <img :src="getImgUrl(project.thumbnailUrl)" alt class="h-full w-full object-cover" />
            </div>
            <div
              class="movable-gallery-project-title pointer-events-none text-gray-200 absolute leading-none smli-font"
            >
              <div class="movable-gallery-project-title-split uppercase text-center leading-tight">
                <p class="letter-spacing-10">{{ project.heroSection.title }}</p>
              </div>
            </div>
          </div>
          <div class="movable-gallery-project-detail z-10 mt-10">
            <div
              class="movable-gallery-project-detail-line border border-gray-900 pointer-events-none"
            ></div>
            <p class="text-sm letter-spacing-2 uppercase">{{ project.heroSection.date }}</p>
          </div>
        </router-link>
        </div>
      </div>

      <div class="mouseareas absolute top-0 bottom-0 h-full w-full left-0" style="z-index: -10;">
        <div class="mouseareas-left"></div>
        <div class="mouseareas-right"></div>
      </div>
      <keep-alive>
        <AppButton v-bind:buttondata="buttondata"></AppButton>
      </keep-alive>
    </div>
  </div>
</template>

<script>
import appbutton from "../components/appbutton.vue";
import projects from '../json/projects.json'

export default {
  name: "productcarousel",
  components: {
    AppButton: appbutton
  },
  data() {
    return {
      projects: projects,
      buttondata: {
        fronttext: "Browse all our content",
        hovertext: "Go ahead !",
        buttoncolorclass: "bg-white",
        buttonbackbganimationclass: "bg-gray-900",
        buttontextcolorclass: "text-gray-900",
        buttontexthovercolorclass: "text-white"
      },
      productcarouseldata: [
        {
          id: "01",
          title: "Kusum Sarovar Gates",
          publisheddate: "March 2019",
          img: "1.jpg"
        },
        {
          id: "02",
          title: "Kusum Sarovar Gates",
          publisheddate: "April 2019",
          img: "2.jpg"
        },
        {
          id: "03",
          title: "Kusum Sarovar Gates",
          publisheddate: "May 2019",
          img: "3.jpg"
        },
        {
          id: "04",
          title: "Kusum Sarovar Gates",
          publisheddate: "January 2020",
          img: "4.jpg"
        }
      ]
    };
  },
  methods: {
    getImgUrl: function(img) {
      return require("../assets/img/" + img);
    }
  }
};
</script>