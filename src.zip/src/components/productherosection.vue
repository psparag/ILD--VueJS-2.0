<template>
  <div class="relative c-z-5">
    <div
      class="information-container-grid--heading-container information-grid-row-1 mx-auto text-center"
    >
      <p class="information-number text-2xl smli-font text-gray-900 letter-spacing-2">{{herosectiondata.id}}</p>

      <p class="information-year mt-10 text-sm letter-spacing-2 uppercase text-gray-500">{{herosectiondata.date}}</p>

      <p
        class="information-name mt-8 text-5xl letter-spacing-10 smli-font text-gray-900 uppercase"
      >{{herosectiondata.title}}</p>
    </div>
    <div class="information-container-grid--image-container mx-auto mt-24 information-grid-row-2">
      <img v-bind:src="getImgUrl(herosectiondata.imageUrl)" alt class="object-cover w-full h-full" />
    </div>
  </div>
</template>

<script>
    export default {
        name:'prodcutherosection',
        props: {
            herosectiondata : Object
        },
        methods: {
            getImgUrl: function(img) {
                return require('../assets/img/'+img)
            }
        }
    }
</script>