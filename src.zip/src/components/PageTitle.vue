<template>
    <div class="top-page-title--section content-container pt-24 fixed c-z-3">
          <div class="title-heading--small-text text-2xl uppercase">{{pageTitle}}</div>
    </div>
</template>

<script>
export default {
    name: "PageTitle",
    props: {
        pageTitle: {
            type: String
        }
    }
}
</script>