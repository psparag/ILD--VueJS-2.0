<template>
  <!-- Sidebar Section starts -->
  <div class="sidebar-fixed-section pt-24 fixed right-0 h-full z-50 pointer-events-none">
    <div class="overflow-y-hidden sidebar-fixed-section-grid--div">
      <p
        class="text-xs sidebar-fixed-section-grid--menu uppercase text-right text-gray-900 pointer-events-auto animate-link"
      >Menu</p>
    </div>
    <p
      class="sidebar-fixed-section-grid--email uppercase text-xs text-gray-900 pointer-events-auto animate-link"
    >contact@ILDLIMITED.COM</p>
    <div class="sidebar-fixed-section-grid--dark-mode uppercase text-xs animate-link">
      <p
        class="sidebar-fixed-section-grid-dark-mode--text ml-6 text-gray-900 pointer-events-auto"
      >Try the dark mode</p>
    </div>
  </div>
  <!-- Sidebar Section ends -->
</template>		


<script>
export default {
  name: "appheader"
};
</script>