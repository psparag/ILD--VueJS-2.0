<template>
  <div class="top-section hero-section pt-24 w-full custom-bg-gray-100 bg-gray-100 relative c-z-4">
    <div class="title-heading content-container">
      <div
        class="title-heading--main-text leading-none uppercase text-gray-900 font-medium smli-font pb-24"
        v-html="herodata.title"
      ></div>
    </div>
  </div>
</template>

<script>
export default {
  name: "herosection",
  props: ["herodata"],
  data() {
    return {};
  }
};
</script>

<style >
.hero-heding-text--animation{
white-space: pre-line;
float: none;
/* display: inline-block; */
margin-right: 0px;
cursor: default;
overflow: hidden;
}
</style>

