<template>
  <div class="about">
    <app-cursor></app-cursor>

    <appnavigation></appnavigation>

    <appheader></appheader>

    <!-- main section starts -->
    <section class="viewport">
      <div id="scroll-container" class="scroll-container">
        <div class="content bg-white">
          <page-title pageTitle="© About Us"></page-title>
          <herosection v-bind:herodata="herodata"></herosection>

          <!-- Container starts -->
          <div class="content-container relative c-z-2">
            <div class="break-image-section">
              <div class="break-image-section--grid pt-48 w-full">
                <heading v-bind:headingdata="headingdata"></heading>
                <imagegallerywithbackground></imagegallerywithbackground>
                <heading v-bind:headingdata="headingdata2"></heading>
                <imagegallerywithtext v-bind:imagegallerydata="imagegallerydata"></imagegallerywithtext>
                <heading v-bind:headingdata="headingdata2"></heading>
              </div>
            </div>

            <productcarousel></productcarousel>
            <heading v-bind:headingdata="headingdata2"></heading>
            <imagegallery v-bind:imagegalleryclass="imagegalleryclass"></imagegallery>
            <heading v-bind:headingdata="headingdata2"></heading>
            <productcarousel></productcarousel>
            <div class="h-screen"></div>
          </div>
          <!-- Container ends -->
        </div>
      </div>
    </section>
    <!-- main section ends  -->
  </div>
</template>

<script>
import productcarousel from "../components/productcarousel"
import herosection from "../components/herosection"
import imagegallery from "../components/imagegallery"
import heading from "../components/heading"
import imagegallerywithtext from "../components/imagegallerywithtext"
import imagegallerywithbackground from "../components/imagegallerywithbackground"

import { testmixins } from "../assets/mixins/testmixins.js"

export default {
  name: "home",
  mixins: [testmixins],
  components: {
    productcarousel: productcarousel,
    herosection: herosection,
    imagegallery: imagegallery,
    imagegallerywithbackground: imagegallerywithbackground,
    heading: heading,
    imagegallerywithtext: imagegallerywithtext
  },
  data() {
    return {
      herodata: {
        subtitle: `
                    <span class="uppercase text-gray-900 smli-font letter-spacing-2">
                        About Us
                	</span>`,
        title: `<div class="hero-heding-text--animation overflow-hidden"><p class="text-left opacity-60">Intelligent</p></div>
                <div class="hero-heding-text--animation overflow-hidden"><p class="title-heading-main-text--mobile-margin-top -mt-4 opacity-70 herosection-margin-left-line-2">Inspiring</p></div>
                <div class="hero-heding-text--animation overflow-hidden"><p class="title-heading-main-text--mobile-margin-top -mt-4 opacity-80 text-right mr-10">Inventive</p></div>
                <div class="hero-heding-text--animation overflow-hidden"><p class="title-heading-main-text--mobile-margin-top -mt-4 opacity-90 herosection-margin-left-line-4">Iconic</p></div>
                <div class="hero-heding-text--animation overflow-hidden"><p class="title-heading-main-text--mobile-margin-top -mt-4 ">Illumination</p></div>`
      },
      headingdata: {
        headingid: "01",
        headingsize: "small",
        headingtext: "About Innovative lighting designs",
        paragraphtext:
          "Welcome to the future in lighting solutions. We don’t just do lighting. We do aesthetic illumination, paired with pioneering technology that is both user-friendly and cutting edge."
      },
      headingdata2: {
        headingid: "02",
        headingsize: "large",
        headingtext: "Projects by ild",
        paragraphtext:
          "Innovation is more than a buzzword for us, it’s a way of life. At ILD, we understand the value that lighting adds to architecture and space design. Our aim is to create energy efficient, technology-driven and aesthetically stunning lighting solutions for our clients across various segments."
      },
      imagegallerydata: [
        {
          id: "01",
          text:
            "Innovation is more than a buzzword for us, it’s a way of life. At ILD, we understand the value that lighting adds to architecture and space design.",
          img: "1.jpg"
        },
        {
          id: "02",
          text:
            "Innovation is more than a buzzword for us, it’s a way of life. At ILD, we understand the value that lighting adds to architecture and space design.",
          img: "2.jpg"
        },
        {
          id: "03",
          text:
            "Innovation is more than a buzzword for us, it’s a way of life. At ILD, we understand the value that lighting adds to architecture and space design.",
          img: "3.jpg"
        },
        {
          id: "04",
          text:
            "Innovation is more than a buzzword for us, it’s a way of life. At ILD, we understand the value that lighting adds to architecture and space design.",
          img: "4.jpg"
        }
      ],

      marginclass: "mt-24",
      imagegalleryclass: "pt-40"
    };
  }
};
</script>