<template>
  <div class="products">
    <app-cursor></app-cursor>
    <appnavigation></appnavigation>
    <appheader></appheader>

    <!-- main section starts -->
    <section class="viewport">
      <div id="scroll-container" class="scroll-container">
        <div class="content bg-white">
           <page-title :pageTitle="getProject.heroSection.title"></page-title>
            <div
              class="background-color-section c-full-width c-bg-gray-100-with-opacity h-screen bg-gray-100 absolute c-z-4"
            ></div>
          <div class="relative c-z-6">

            <!-- Container starts -->
            <div class="content-container relative">
              <div class="information-container pt-24">
                <div class="information-container--grid">
                  <productherosection v-bind:herosectiondata="getProject.heroSection"></productherosection>
                  <heading v-bind:headingdata="getProject.headingOne"></heading>
                </div>
              </div>
              <div class="break-image-section information-page-break-section">
                <div
                  class="break-image-section--grid information-page-break-section--grid w-full productsingle-page-gridgap"
                >
                  <imagegallery v-bind:imagegalleryclass="imagegalleryclass"></imagegallery>
                  <imagegallery></imagegallery>
                  <heading v-bind:headingdata="getProject.headingTwo"></heading>
                </div>
              </div>
              <div class="pb-56"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <!-- main section ends  -->
</template>

<script>
import productherosection from "../components/productherosection"
import heading from "../components/heading"
import imagegallery from "../components/imagegallery"
import { testmixins } from "../assets/mixins/testmixins.js" 

import projects from '../json/projects.json'

export default {
    name:'productsingle',
    mixins: [testmixins],
    components:{
        'productherosection': productherosection,
        'heading': heading,
        'imagegallery': imagegallery,
    },
    data(){ 
        return {
            projects: projects,
            imagegalleryclass: 'pt-40',
        }
       
    },
    props:{
        slug: {
            type: String,
            required: true
        }
    },
    computed: {
        getProject() {
            return this.projects.find(
                project => project.slug === this.slug
            )
            
        }
    },
     mounted: function(){
      //var bg = document.querySelector(".background-color-section");
      window.onscroll = function() {scrollFunction()};

        function scrollFunction() {
          var height = document.querySelector(".background-color-section").offsetHeight;
          if (document.body.scrollTop > height - 100 || document.documentElement.scrollTop > height - 100) {
            document.querySelector(".top-page-title--section").style.zIndex = 10 ;
          }
          else if(document.body.scrollTop < height || document.documentElement.scrollTop < height){
            document.querySelector(".top-page-title--section").style.zIndex = 2 ;
          }
        }

    }

}
</script>

<style scoped>
.break-image-section-grid--row2 {
  margin-right: 4.5vw;
  margin-left: 4.5vw;
}
</style>
