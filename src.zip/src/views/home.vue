<template>
  <div class="home">
    <app-cursor></app-cursor>
    <appnavigation></appnavigation>
    <appheader></appheader>

    <!-- main section starts -->
    <section class="viewport">
      <div id="scroll-container" class="scroll-container">
        <div class="content bg-white">
          <page-title pageTitle="© Innovative lighting designs private limited"></page-title>
          <herosection v-bind:herodata="herodata"></herosection>
          <!-- Container starts -->
          <div class="content-container relative c-z-2">
            <div class="break-image-section">
              <div class="break-image-section--grid pt-48 w-full">
                <heading v-bind:headingdata="headingdata"></heading>
                <imagegallery v-bind:imagegalleryclass="imagegalleryclass"></imagegallery>
                <heading v-bind:headingdata="headingdata2"></heading>
              </div>
            </div>

            <productcarousel></productcarousel>

            <div class="feature-partner-section">
              <div class="feature-partner-section--grid py-56 w-full">
                <div
                  class="feature-partner-section-grid--row1 leading-snug text-gray-900 smli-font text-5xl letter-spacing-10"
                >
                  <p class="text-center section-heading mx-auto leading-none uppercase">
                    <span class="text-gray-500">03/</span>Featured partner products and projects
                  </p>
                </div>
                <div class="feature-partner-section-grid--row2 pt-40 text-gray-800">
                  <div class="feature-partner-section-grid-row2">
                    <featuredproducts></featuredproducts>
                    <featuredproducts v-bind:marginclass="marginclass"></featuredproducts>
                  </div>
                </div>
                <div class="feature-partner-section-grid--row3 mx-auto text-center leading-tight">
                  <heading v-bind:headingdata="headingdata3"></heading>

                  <keep-alive>
                    <AppButton v-bind:buttondata="buttonblackdata"></AppButton>
                  </keep-alive>
                </div>
              </div>
            </div>
          </div>
          <!-- Container ends -->
        </div>
      </div>
    </section>
    <!-- main section ends  -->
  </div>
</template>

<script>
import appbutton from "../components/appbutton"
import productcarousel from "../components/productcarousel"
import herosection from "../components/herosection"
import featuredproducts from "../components/featuredproducts"
import imagegallery from "../components/imagegallery"
import heading from "../components/heading"
import { testmixins } from "../assets/mixins/testmixins.js"

export default {
  name: "home",
  mixins: [testmixins],
  components: {
    AppButton: appbutton,
    productcarousel: productcarousel,
    herosection: herosection,
    featuredproducts: featuredproducts,
    imagegallery: imagegallery,
    heading: heading
  },
  data() {
    return {
      herodata: {
        subtitle: `<span>
                    ©
                    <span class="uppercase text-gray-900 smli-font letter-spacing-2">
                        ILD
                    </span>
                </span>`,
        title: `<div class="hero-heding-text--animation overflow-hidden"><p class="text-left opacity-60">Intelligent</p></div>
                <div class="hero-heding-text--animation overflow-hidden"><p class="title-heading-main-text--mobile-margin-top -mt-4 opacity-70 herosection-margin-left-line-2">Inspiring</p></div>
                <div class="hero-heding-text--animation overflow-hidden"><p class="title-heading-main-text--mobile-margin-top -mt-4 opacity-80 text-right mr-10">Inventive</p></div>
                <div class="hero-heding-text--animation overflow-hidden"><p class="title-heading-main-text--mobile-margin-top -mt-4 opacity-90 herosection-margin-left-line-4">Iconic</p></div>
                <div class="hero-heding-text--animation overflow-hidden"><p class="title-heading-main-text--mobile-margin-top -mt-4 ">Illumination</p></div>`
      },
      buttonblackdata: {
        fronttext: "Learn more about us",
        hovertext: "Go ahead !",
        buttoncolorclass: "bg-gray-900",
        buttonbackbganimationclass: "bg-gray-100",
        buttontextcolorclass: "text-white",
        buttontexthovercolorclass: "text-gray-900"
      },
      headingdata: {
        headingid: "01",
        headingsize: "small",
        headingtext: "Creative lighting that understands design",
        paragraphtext:
          "<p>The best spatial designs deserve the best lighting solutions. At ILD, the latest lighting trends, from across the world, are combined with pioneering technology to create extraordinary luminaries.</p> <p>This is the lighting your work of art needs.</p> "
      },
      headingdata2: {
        headingid: "02",
        headingsize: "large",
        headingtext: "Projects by ild",
        paragraphtext:
          "<p>Innovation is more than a buzzword for us, it’s a way of life. At ILD, we understand the value that lighting adds to architecture and space design. Our aim is to create energy efficient, technology-driven and aesthetically stunning lighting solutions for our clients across various segments.</p>"
      },
      headingdata3: {
        headingid: "04",
        headingsize: "large",
        headingtext: "who we are",
        paragraphtext:
          "<p>ILD offers the most technologically advanced, energy-efficient, and superior grade lighting systems which understand design and illuminate spaces the way they should be. We strive to give your creativity the light it needs to shine and resonate through the world. As exclusive distributors for the leading lighting manufacturers in the world, ILD is known for its quality and trust and stands in a unique position to understand your project like no one else.</p> <p>With our constant research on global trends and a cohesive design team, ILD is a well-rounded, one-stop destination for creators who want their work to shine.</p>"
      },
      marginclass: "mt-32",
      imagegalleryclass: "pt-40"
    };
  }
};
</script>