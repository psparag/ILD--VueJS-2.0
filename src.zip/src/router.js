import Vue from 'vue'
import VueRouter from 'vue-router'
import home from './views/home'
import about from './views/about'
import projects from'./json/projects.json'

Vue.use(VueRouter);

export default new VueRouter({
    mode: 'history',
    scrollBehavior (to, from, savedPosition) {
        if (savedPosition) {
            return savedPosition
          } else {
            return { x: 0, y: 0 }
          }
      },
    routes: [
    {
        path: '/',
        name: 'home',
        component: home,
        props: true
    },
    {
        path: '/about',
        name: 'about',
        props: true,
        component: about,
        // lazy load routes
        //component: () => import(/* webpackChunkName: "about" */ "./views/about")
    },
    {
        path: '/loader',
        name: 'loader',
        props: true,
        // lazy load routes
        component: () => import(/* webpackChunkName: "loaderpage" */ "./views/loaderpage")
    },
    {
        path: '/project/:slug',
        name: 'ProductSingle',
        props: true,
        // lazy load routes
        component: () => import(/* webpackChunkName: "productsingle" */ "./views/productsingle"),
        beforeEnter: (to, from, next) => {
            const exist = projects.find(
                project => project.slug === to.params.slug
            )
            if(exist){
                next();
            }
            else{
                next({name: "notFound"})
            }
          }
    },
    {
        path: '/404',
        alias: '*',
        name: 'notFound',
        component: () => import(/* webpackChunkName: "notfound" */ "./views/404")
    }
]
})